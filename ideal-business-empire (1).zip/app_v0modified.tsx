// Initialize the game when the page loads
let gameManager
let uiManager

// Declare GameManager and UIManager classes or import them here
class GameManager {
  getBusinesses() {
    return []
  }
  showNotification(message, type) {
    console.log(message, type)
  }
  loadGame() {
    console.log("Game loaded")
  }
  saveGame() {
    console.log("Game saved")
  }
}

class UIManager {
  constructor(gameManager) {
    this.gameManager = gameManager
  }
  updateUI() {
    console.log("UI updated")
  }
}

document.addEventListener("DOMContentLoaded", () => {
  // Initialize game manager
  gameManager = new GameManager()

  // Initialize UI manager
  uiManager = new UIManager(gameManager)

  // Add some initial businesses if none exist
  if (gameManager.getBusinesses().length === 0) {
    // Add some starter business options
    gameManager.showNotification("Welcome to Ideal Business Empire! Start by purchasing your first business.", "info")
  }

  // Add CSS animation for slideOut
  const style = document.createElement("style")
  style.textContent = `
        @keyframes slideOut {
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #6b7280;
            font-size: 1.1rem;
        }
        
        .current-player {
            background: rgba(102, 126, 234, 0.1);
            border-left: 4px solid #667eea;
        }
        
        .owned {
            opacity: 0.7;
            position: relative;
        }
        
        .owned::after {
            content: '✓ OWNED';
            position: absolute;
            top: 10px;
            right: 10px;
            background: #10b981;
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .disabled {
            opacity: 0.6;
            cursor: not-allowed;
            pointer-events: none;
        }
        
        .notification-content {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .notification-content i {
            font-size: 1.2rem;
        }
    `
  document.head.appendChild(style)
})

// Global functions for onclick handlers
window.gameManager = null
window.uiManager = null

// Make managers globally accessible after initialization
document.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    window.gameManager = gameManager
    window.uiManager = uiManager
  }, 100)
})

// Handle page visibility changes for offline earnings
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && gameManager) {
    // Player returned to the page, calculate offline earnings
    gameManager.loadGame()
    uiManager.updateUI()
  }
})

// Auto-save every 30 seconds
setInterval(() => {
  if (gameManager) {
    gameManager.saveGame()
  }
}, 30000)

// Handle beforeunload to save game
window.addEventListener("beforeunload", () => {
  if (gameManager) {
    gameManager.saveGame()
  }
})
