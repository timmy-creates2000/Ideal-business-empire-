class UIManager {
  constructor(gameManager) {
    this.gameManager = gameManager
    this.currentTab = "businesses"
    this.init()
  }

  init() {
    this.setupEventListeners()
    this.setupNotifications()
    this.updateUI()
    this.startUIUpdates()
  }

  setupEventListeners() {
    // Tab navigation
    document.querySelectorAll(".tab-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const tab = e.currentTarget.dataset.tab
        this.switchTab(tab)
      })
    })

    // Modal controls
    document.querySelectorAll(".modal-close").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        this.closeModal(e.target.closest(".modal"))
      })
    })

    // Click outside modal to close
    document.querySelectorAll(".modal").forEach((modal) => {
      modal.addEventListener("click", (e) => {
        if (e.target === modal) {
          this.closeModal(modal)
        }
      })
    })

    // Business actions
    document.getElementById("addBusinessBtn").addEventListener("click", () => {
      this.showBusinessModal()
    })

    // Employee actions
    document.getElementById("hireEmployeeBtn").addEventListener("click", () => {
      this.showEmployeeModal()
    })

    // Real estate actions
    document.getElementById("buyRealEstateBtn").addEventListener("click", () => {
      this.showRealEstateModal()
    })

    // Investment actions
    document.querySelectorAll("[data-investment]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const type = e.currentTarget.dataset.investment
        this.gameManager.makeInvestment(type)
        this.updateInvestmentsTab()
      })
    })
  }

  setupNotifications() {
    window.addEventListener("showNotification", (e) => {
      this.showNotification(e.detail.message, e.detail.type)
    })
  }

  switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll(".tab-btn").forEach((btn) => {
      btn.classList.remove("active")
    })
    document.querySelector(`[data-tab="${tabName}"]`).classList.add("active")

    // Update tab content
    document.querySelectorAll(".tab-pane").forEach((pane) => {
      pane.classList.remove("active")
    })
    document.getElementById(tabName).classList.add("active")

    this.currentTab = tabName
    this.updateTabContent(tabName)
  }

  updateTabContent(tabName) {
    switch (tabName) {
      case "businesses":
        this.updateBusinessesTab()
        break
      case "investments":
        this.updateInvestmentsTab()
        break
      case "employees":
        this.updateEmployeesTab()
        break
      case "realestate":
        this.updateRealEstateTab()
        break
      case "prestige":
        this.updatePrestigeTab()
        break
      case "leaderboard":
        this.updateLeaderboardTab()
        break
    }
  }

  updateUI() {
    // Update header stats
    document.getElementById("totalMoney").textContent =
      "$" + this.gameManager.formatMoney(this.gameManager.getTotalMoney())
    document.getElementById("netWorth").textContent =
      "$" + this.gameManager.formatMoney(this.gameManager.calculateNetWorth())
    document.getElementById("playerLevel").textContent = "Level " + this.gameManager.data.playerLevel
    document.getElementById("passiveIncome").textContent =
      "$" + this.gameManager.formatMoney(this.gameManager.calculatePassiveIncome()) + "/hr"

    // Update XP progress
    const xpProgress = this.gameManager.getXPProgress()
    document.getElementById("xpProgress").style.width = xpProgress.percentage + "%"
    document.getElementById("xpText").textContent = `${xpProgress.progress} / ${xpProgress.required} XP`

    // Update current tab
    this.updateTabContent(this.currentTab)
  }

  updateBusinessesTab() {
    const grid = document.getElementById("businessesGrid")
    const businesses = this.gameManager.getBusinesses()

    grid.innerHTML = ""

    businesses.forEach((business) => {
      const businessType = this.gameManager.businessTypes[business.type]
      const upgradeCost = business.cost * business.level * 0.5

      const card = document.createElement("div")
      card.className = "card business-card business-owned"
      card.innerHTML = `
                <div class="card-header">
                    <div class="card-title">
                        ${businessType.icon} ${business.name}
                    </div>
                    <div class="card-badge">Level ${business.level}</div>
                </div>
                <div class="card-content">
                    <div class="card-stat">
                        <span class="card-stat-label">Revenue:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(business.revenue)}/hr</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Employees:</span>
                        <span class="card-stat-value">${business.employees.length}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Upgrade Cost:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(upgradeCost)}</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="gameManager.upgradeBusiness('${business.id}'); uiManager.updateUI();">
                        <i class="fas fa-arrow-up"></i> Upgrade
                    </button>
                </div>
            `
      grid.appendChild(card)
    })

    if (businesses.length === 0) {
      grid.innerHTML =
        '<div class="empty-state">No businesses yet. Start your empire by purchasing your first business!</div>'
    }
  }

  updateInvestmentsTab() {
    const grid = document.getElementById("investmentsGrid")
    const investments = this.gameManager.getInvestments()

    grid.innerHTML = ""

    investments.forEach((investment) => {
      const currentValue = investment.shares * investment.currentPrice
      const profit = currentValue - investment.amount
      const profitPercent = ((investment.currentPrice - investment.purchasePrice) / investment.purchasePrice) * 100
      const profitClass = profit >= 0 ? "profit-positive" : "profit-negative"

      const card = document.createElement("div")
      card.className = `card investment-card ${profitClass}`
      card.innerHTML = `
                <div class="card-header">
                    <div class="card-title">
                        ${this.getInvestmentIcon(investment.type)} ${investment.name}
                    </div>
                    <div class="card-badge">${investment.type.toUpperCase()}</div>
                </div>
                <div class="card-content">
                    <div class="card-stat">
                        <span class="card-stat-label">Shares:</span>
                        <span class="card-stat-value">${investment.shares.toFixed(4)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Current Price:</span>
                        <span class="card-stat-value">$${investment.currentPrice.toFixed(2)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Current Value:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(currentValue)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Profit/Loss:</span>
                        <span class="card-stat-value profit">${profit >= 0 ? "+" : ""}$${this.gameManager.formatMoney(profit)} (${profitPercent.toFixed(1)}%)</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn btn-success" onclick="gameManager.sellInvestment('${investment.id}'); uiManager.updateUI();">
                        <i class="fas fa-dollar-sign"></i> Sell
                    </button>
                </div>
            `
      grid.appendChild(card)
    })

    if (investments.length === 0) {
      grid.innerHTML = '<div class="empty-state">No investments yet. Start building your portfolio!</div>'
    }
  }

  updateEmployeesTab() {
    const grid = document.getElementById("employeesGrid")
    const employees = this.gameManager.getEmployees()

    grid.innerHTML = ""

    employees.forEach((employee) => {
      const employeeType = this.gameManager.employeeTypes[employee.type]
      const upgradeCost = employee.salary * employee.level * 2

      const card = document.createElement("div")
      card.className = "card employee-card"
      card.innerHTML = `
                <div class="employee-avatar">
                    ${employeeType.icon}
                </div>
                <div class="card-title">${employee.name}</div>
                <div class="card-content">
                    <div class="card-stat">
                        <span class="card-stat-label">Position:</span>
                        <span class="card-stat-value">${employeeType.name}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Level:</span>
                        <span class="card-stat-value">${employee.level}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Salary:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(employee.salary)}/month</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Productivity Bonus:</span>
                        <span class="card-stat-value">+$${this.gameManager.formatMoney(employee.bonus * employee.level)}/hr</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="gameManager.upgradeEmployee('${employee.id}'); uiManager.updateUI();">
                        <i class="fas fa-arrow-up"></i> Promote ($${this.gameManager.formatMoney(upgradeCost)})
                    </button>
                </div>
            `
      grid.appendChild(card)
    })

    if (employees.length === 0) {
      grid.innerHTML = '<div class="empty-state">No employees yet. Build your team to boost productivity!</div>'
    }
  }

  updateRealEstateTab() {
    const grid = document.getElementById("realestateGrid")
    const realEstates = this.gameManager.getRealEstates()

    grid.innerHTML = ""

    realEstates.forEach((realEstate) => {
      const realEstateType = this.gameManager.realEstateTypes[realEstate.type]
      const roi = ((realEstate.monthlyIncome * 12) / realEstate.price) * 100

      const card = document.createElement("div")
      card.className = "card"
      card.innerHTML = `
                <div class="card-header">
                    <div class="card-title">
                        ${realEstateType.icon} ${realEstate.name}
                    </div>
                </div>
                <div class="card-content">
                    <div class="card-stat">
                        <span class="card-stat-label">Location:</span>
                        <span class="card-stat-value">${realEstate.location}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Purchase Price:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(realEstate.price)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Monthly Income:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(realEstate.monthlyIncome)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">ROI:</span>
                        <span class="card-stat-value">${roi.toFixed(1)}% annually</span>
                    </div>
                </div>
            `
      grid.appendChild(card)
    })

    if (realEstates.length === 0) {
      grid.innerHTML = '<div class="empty-state">No real estate yet. Invest in properties for passive income!</div>'
    }
  }

  updatePrestigeTab() {
    const grid = document.getElementById("prestigeGrid")
    const prestigeItems = this.gameManager.getPrestigeItems()

    // Update prestige points display
    document.getElementById("prestigePoints").textContent = `${this.gameManager.data.prestigePoints} Prestige Points`

    grid.innerHTML = ""

    // Show available prestige items
    Object.entries(this.gameManager.prestigeTypes).forEach(([type, prestigeType]) => {
      const owned = prestigeItems.find((item) => item.type === type)

      const card = document.createElement("div")
      card.className = `card prestige-card ${owned ? "owned" : ""}`
      card.innerHTML = `
                <div class="prestige-icon">${prestigeType.icon}</div>
                <div class="card-title">${prestigeType.name}</div>
                <div class="card-content">
                    <p>${prestigeType.description}</p>
                    <div class="card-stat">
                        <span class="card-stat-label">Price:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(prestigeType.price)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Prestige Points:</span>
                        <span class="card-stat-value">${prestigeType.points}</span>
                    </div>
                </div>
                <div class="card-actions">
                    ${
                      owned
                        ? '<div class="btn btn-success disabled"><i class="fas fa-check"></i> Owned</div>'
                        : `<button class="btn btn-primary" onclick="gameManager.purchasePrestigeItem('${type}'); uiManager.updateUI();">
                            <i class="fas fa-shopping-cart"></i> Purchase
                        </button>`
                    }
                </div>
            `
      grid.appendChild(card)
    })
  }

  updateLeaderboardTab() {
    const container = document.getElementById("leaderboardContainer")
    const leaderboard = this.gameManager.getLeaderboard()

    container.innerHTML = ""

    leaderboard.forEach((player, index) => {
      const isCurrentPlayer = player.name === this.gameManager.data.playerName

      const item = document.createElement("div")
      item.className = `leaderboard-item ${isCurrentPlayer ? "current-player" : ""}`
      item.innerHTML = `
                <div class="leaderboard-rank">#${index + 1}</div>
                <div class="leaderboard-info">
                    <div class="leaderboard-name">${player.name} ${isCurrentPlayer ? "(You)" : ""}</div>
                    <div class="leaderboard-level">Level ${player.level} • ${player.prestigePoints} Prestige Points</div>
                </div>
                <div class="leaderboard-worth">$${this.gameManager.formatMoney(player.netWorth)}</div>
            `
      container.appendChild(item)
    })
  }

  showBusinessModal() {
    const modal = document.getElementById("businessModal")
    const grid = document.getElementById("businessTypesGrid")

    grid.innerHTML = ""

    Object.entries(this.gameManager.businessTypes).forEach(([type, businessType]) => {
      const card = document.createElement("div")
      card.className = "card"
      card.innerHTML = `
                <div class="card-header">
                    <div class="card-title">
                        ${businessType.icon} ${businessType.name}
                    </div>
                </div>
                <div class="card-content">
                    <p>${businessType.description}</p>
                    <div class="card-stat">
                        <span class="card-stat-label">Cost:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(businessType.baseCost)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Revenue:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(businessType.baseRevenue)}/hr</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="gameManager.purchaseBusiness('${type}'); uiManager.closeModal(document.getElementById('businessModal')); uiManager.updateUI();">
                        <i class="fas fa-shopping-cart"></i> Purchase
                    </button>
                </div>
            `
      grid.appendChild(card)
    })

    this.showModal(modal)
  }

  showEmployeeModal() {
    const modal = document.getElementById("employeeModal")
    const grid = document.getElementById("employeeTypesGrid")

    grid.innerHTML = ""

    Object.entries(this.gameManager.employeeTypes).forEach(([type, employeeType]) => {
      const yearlySalary = employeeType.salary * 12

      const card = document.createElement("div")
      card.className = "card"
      card.innerHTML = `
                <div class="card-header">
                    <div class="card-title">
                        ${employeeType.icon} ${employeeType.name}
                    </div>
                </div>
                <div class="card-content">
                    <p>${employeeType.description}</p>
                    <div class="card-stat">
                        <span class="card-stat-label">Yearly Salary:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(yearlySalary)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Productivity Bonus:</span>
                        <span class="card-stat-value">+$${this.gameManager.formatMoney(employeeType.bonus)}/hr</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="gameManager.hireEmployee('${type}'); uiManager.closeModal(document.getElementById('employeeModal')); uiManager.updateUI();">
                        <i class="fas fa-user-plus"></i> Hire
                    </button>
                </div>
            `
      grid.appendChild(card)
    })

    this.showModal(modal)
  }

  showRealEstateModal() {
    const modal = document.getElementById("realEstateModal")
    const grid = document.getElementById("realEstateTypesGrid")

    grid.innerHTML = ""

    Object.entries(this.gameManager.realEstateTypes).forEach(([type, realEstateType]) => {
      const roi = ((realEstateType.income * 12) / realEstateType.price) * 100

      const card = document.createElement("div")
      card.className = "card"
      card.innerHTML = `
                <div class="card-header">
                    <div class="card-title">
                        ${realEstateType.icon} ${realEstateType.name}
                    </div>
                </div>
                <div class="card-content">
                    <p>${realEstateType.description}</p>
                    <div class="card-stat">
                        <span class="card-stat-label">Price:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(realEstateType.price)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Monthly Income:</span>
                        <span class="card-stat-value">$${this.gameManager.formatMoney(realEstateType.income)}</span>
                    </div>
                    <div class="card-stat">
                        <span class="card-stat-label">Annual ROI:</span>
                        <span class="card-stat-value">${roi.toFixed(1)}%</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="gameManager.purchaseRealEstate('${type}'); uiManager.closeModal(document.getElementById('realEstateModal')); uiManager.updateUI();">
                        <i class="fas fa-building"></i> Purchase
                    </button>
                </div>
            `
      grid.appendChild(card)
    })

    this.showModal(modal)
  }

  showModal(modal) {
    modal.classList.add("active")
    document.body.style.overflow = "hidden"
  }

  closeModal(modal) {
    modal.classList.remove("active")
    document.body.style.overflow = ""
  }

  getInvestmentIcon(type) {
    const icons = {
      stock: "📈",
      crypto: "₿",
      bonds: "📋",
      commodities: "🥇",
    }
    return icons[type] || "📊"
  }

  showNotification(message, type = "info") {
    const container = document.getElementById("notificationContainer")

    const notification = document.createElement("div")
    notification.className = `notification ${type}`
    notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${this.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `

    container.appendChild(notification)

    // Auto remove after 4 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.style.animation = "slideOut 0.3s ease forwards"
        setTimeout(() => {
          container.removeChild(notification)
        }, 300)
      }
    }, 4000)
  }

  getNotificationIcon(type) {
    const icons = {
      success: "check-circle",
      error: "exclamation-circle",
      warning: "exclamation-triangle",
      info: "info-circle",
    }
    return icons[type] || "info-circle"
  }

  startUIUpdates() {
    // Update UI every second
    setInterval(() => {
      this.updateUI()
    }, 1000)
  }
}
