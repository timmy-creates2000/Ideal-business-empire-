class GameManager {
  constructor() {
    this.data = {
      totalMoney: 10000,
      playerName: "Business Tycoon",
      playerLevel: 1,
      playerXP: 0,
      businesses: [],
      employees: [],
      investments: [],
      realEstates: [],
      prestigeItems: [],
      prestigePoints: 0,
      lastSave: Date.now(),
    }

    this.businessTypes = {
      retail: {
        name: "Retail Store",
        icon: "🏪",
        baseCost: 5000,
        baseRevenue: 100,
        description: "Sell products to customers",
      },
      restaurant: {
        name: "Restaurant",
        icon: "🍽️",
        baseCost: 8000,
        baseRevenue: 150,
        description: "Serve delicious meals",
      },
      bank: { name: "Bank", icon: "🏦", baseCost: 50000, baseRevenue: 800, description: "Provide financial services" },
      airline: {
        name: "Airline",
        icon: "✈️",
        baseCost: 100000,
        baseRevenue: 1500,
        description: "Transport passengers worldwide",
      },
      clothing: {
        name: "Clothing Store",
        icon: "👕",
        baseCost: 12000,
        baseRevenue: 200,
        description: "Fashion and apparel business",
      },
      it: {
        name: "IT Company",
        icon: "💻",
        baseCost: 25000,
        baseRevenue: 400,
        description: "Technology solutions and software",
      },
      blockchain: {
        name: "Blockchain Firm",
        icon: "₿",
        baseCost: 75000,
        baseRevenue: 1000,
        description: "Cryptocurrency and blockchain services",
      },
      hotel: {
        name: "Hotel Chain",
        icon: "🏨",
        baseCost: 60000,
        baseRevenue: 900,
        description: "Hospitality and accommodation",
      },
    }

    this.employeeTypes = {
      manager: {
        name: "Manager",
        icon: "👔",
        salary: 5000,
        bonus: 50,
        description: "Increases overall business efficiency",
      },
      developer: {
        name: "Developer",
        icon: "👨‍💻",
        salary: 7000,
        bonus: 80,
        description: "Boosts IT and tech business revenue",
      },
      salesperson: {
        name: "Salesperson",
        icon: "🤝",
        salary: 4000,
        bonus: 60,
        description: "Increases retail and sales revenue",
      },
      accountant: {
        name: "Accountant",
        icon: "📊",
        salary: 6000,
        bonus: 40,
        description: "Reduces business costs and taxes",
      },
      marketing: {
        name: "Marketing Specialist",
        icon: "📢",
        salary: 5500,
        bonus: 70,
        description: "Attracts more customers",
      },
      security: {
        name: "Security Officer",
        icon: "🛡️",
        salary: 3500,
        bonus: 30,
        description: "Protects business assets",
      },
      chef: { name: "Head Chef", icon: "👨‍🍳", salary: 6500, bonus: 90, description: "Improves restaurant quality" },
      pilot: { name: "Pilot", icon: "👨‍✈️", salary: 12000, bonus: 150, description: "Essential for airline operations" },
    }

    this.realEstateTypes = {
      apartment: {
        name: "Apartment Complex",
        icon: "🏠",
        price: 50000,
        income: 500,
        description: "Residential rental property",
      },
      house: {
        name: "Luxury House",
        icon: "🏡",
        price: 80000,
        income: 700,
        description: "High-end residential property",
      },
      mansion: { name: "Mansion", icon: "🏰", price: 500000, income: 4000, description: "Ultra-luxury estate" },
      office: {
        name: "Office Building",
        icon: "🏢",
        price: 200000,
        income: 1800,
        description: "Commercial office space",
      },
      mall: { name: "Shopping Mall", icon: "🏬", price: 800000, income: 6000, description: "Large retail complex" },
      warehouse: {
        name: "Warehouse",
        icon: "🏭",
        price: 150000,
        income: 1200,
        description: "Industrial storage facility",
      },
      penthouse: {
        name: "Penthouse Suite",
        icon: "🌆",
        price: 1000000,
        income: 8000,
        description: "Luxury high-rise apartment",
      },
    }

    this.prestigeTypes = {
      luxury_car: { name: "Luxury Sports Car", icon: "🏎️", price: 200000, points: 100, description: "Ferrari 488 GTB" },
      yacht: { name: "Private Yacht", icon: "🛥️", price: 2000000, points: 500, description: "150ft luxury yacht" },
      private_jet: { name: "Private Jet", icon: "🛩️", price: 5000000, points: 1000, description: "Gulfstream G650" },
      watch: { name: "Luxury Watch", icon: "⌚", price: 50000, points: 50, description: "Rolex Submariner" },
      jewelry: {
        name: "Diamond Jewelry",
        icon: "💎",
        price: 100000,
        points: 75,
        description: "Rare diamond collection",
      },
      art: { name: "Fine Art Collection", icon: "🖼️", price: 300000, points: 150, description: "Original masterpieces" },
      wine: {
        name: "Vintage Wine Collection",
        icon: "🍷",
        price: 80000,
        points: 60,
        description: "Rare vintage wines",
      },
    }

    this.loadGame()
    this.startPassiveIncome()
    this.startInvestmentUpdates()
  }

  // Money Management
  getTotalMoney() {
    return this.data.totalMoney
  }

  addMoney(amount) {
    this.data.totalMoney += amount
    this.addXP(Math.floor(amount / 100))
    this.saveGame()
  }

  spendMoney(amount) {
    if (this.data.totalMoney >= amount) {
      this.data.totalMoney -= amount
      this.saveGame()
      return true
    }
    return false
  }

  // XP and Level System
  addXP(amount) {
    this.data.playerXP += amount
    this.checkLevelUp()
    this.saveGame()
  }

  checkLevelUp() {
    const requiredXP = this.getRequiredXP(this.data.playerLevel + 1)
    if (this.data.playerXP >= requiredXP) {
      this.data.playerLevel++
      const bonus = this.data.playerLevel * 1000
      this.addMoney(bonus)
      this.showNotification(
        `Level Up! You reached Level ${this.data.playerLevel} and earned $${this.formatMoney(bonus)}!`,
        "success",
      )
      this.checkLevelUp() // Check for multiple level ups
    }
  }

  getRequiredXP(level) {
    return level * 1000
  }

  getXPProgress() {
    const currentLevelXP = this.getRequiredXP(this.data.playerLevel)
    const nextLevelXP = this.getRequiredXP(this.data.playerLevel + 1)
    const progress = this.data.playerXP - currentLevelXP
    const required = nextLevelXP - currentLevelXP
    return { progress, required, percentage: (progress / required) * 100 }
  }

  // Business Management
  getBusinesses() {
    return this.data.businesses
  }

  purchaseBusiness(type, name) {
    const businessType = this.businessTypes[type]
    if (!businessType) return false

    if (this.spendMoney(businessType.baseCost)) {
      const business = {
        id: this.generateId(),
        name: name || businessType.name,
        type: type,
        level: 1,
        revenue: businessType.baseRevenue,
        cost: businessType.baseCost,
        purchaseDate: Date.now(),
        employees: [],
      }

      this.data.businesses.push(business)
      this.addXP(100)
      this.showNotification(`Successfully purchased ${business.name}!`, "success")
      return true
    }

    this.showNotification("Insufficient funds!", "error")
    return false
  }

  upgradeBusiness(businessId) {
    const business = this.data.businesses.find((b) => b.id === businessId)
    if (!business) return false

    const upgradeCost = business.cost * business.level * 0.5

    if (this.spendMoney(upgradeCost)) {
      business.level++
      business.revenue *= 1.5
      this.addXP(50)
      this.showNotification(`${business.name} upgraded to Level ${business.level}!`, "success")
      return true
    }

    this.showNotification("Insufficient funds for upgrade!", "error")
    return false
  }

  // Employee Management
  getEmployees() {
    return this.data.employees
  }

  hireEmployee(type, businessId = null) {
    const employeeType = this.employeeTypes[type]
    if (!employeeType) return false

    const yearlySalary = employeeType.salary * 12

    if (this.spendMoney(yearlySalary)) {
      const employee = {
        id: this.generateId(),
        name: this.generateEmployeeName(),
        type: type,
        level: 1,
        salary: employeeType.salary,
        bonus: employeeType.bonus,
        businessId: businessId,
        hireDate: Date.now(),
      }

      this.data.employees.push(employee)

      if (businessId) {
        const business = this.data.businesses.find((b) => b.id === businessId)
        if (business) {
          business.employees.push(employee.id)
        }
      }

      this.addXP(25)
      this.showNotification(`Successfully hired ${employee.name} as ${employeeType.name}!`, "success")
      return true
    }

    this.showNotification("Insufficient funds to hire employee!", "error")
    return false
  }

  upgradeEmployee(employeeId) {
    const employee = this.data.employees.find((e) => e.id === employeeId)
    if (!employee) return false

    const upgradeCost = employee.salary * employee.level * 2

    if (this.spendMoney(upgradeCost)) {
      employee.level++
      employee.bonus *= 1.3
      this.addXP(20)
      this.showNotification(`${employee.name} promoted to Level ${employee.level}!`, "success")
      return true
    }

    this.showNotification("Insufficient funds for promotion!", "error")
    return false
  }

  // Investment Management
  getInvestments() {
    return this.data.investments
  }

  makeInvestment(type, amount = 1000) {
    if (!this.spendMoney(amount)) {
      this.showNotification("Insufficient funds for investment!", "error")
      return false
    }

    const price = this.generateInvestmentPrice(type)
    const shares = amount / price

    const investment = {
      id: this.generateId(),
      name: this.generateInvestmentName(type),
      type: type,
      amount: amount,
      shares: shares,
      purchasePrice: price,
      currentPrice: price,
      purchaseDate: Date.now(),
    }

    this.data.investments.push(investment)
    this.addXP(20)
    this.showNotification(`Invested $${this.formatMoney(amount)} in ${investment.name}!`, "success")
    return true
  }

  sellInvestment(investmentId) {
    const investmentIndex = this.data.investments.findIndex((i) => i.id === investmentId)
    if (investmentIndex === -1) return false

    const investment = this.data.investments[investmentIndex]
    const currentValue = investment.shares * investment.currentPrice
    const profit = currentValue - investment.amount

    this.addMoney(currentValue)
    this.data.investments.splice(investmentIndex, 1)

    const profitText =
      profit >= 0 ? `profit of $${this.formatMoney(profit)}` : `loss of $${this.formatMoney(Math.abs(profit))}`
    this.showNotification(`Sold ${investment.name} for a ${profitText}!`, profit >= 0 ? "success" : "warning")
    return true
  }

  updateInvestmentPrices() {
    this.data.investments.forEach((investment) => {
      const volatility = this.getInvestmentVolatility(investment.type)
      const change = (Math.random() - 0.5) * 2 * volatility
      investment.currentPrice *= 1 + change

      // Prevent prices from going negative
      if (investment.currentPrice < 0.01) {
        investment.currentPrice = 0.01
      }
    })
    this.saveGame()
  }

  getInvestmentVolatility(type) {
    const volatilities = {
      stock: 0.05, // 5% max change
      crypto: 0.15, // 15% max change
      bonds: 0.02, // 2% max change
      commodities: 0.08, // 8% max change
    }
    return volatilities[type] || 0.05
  }

  // Real Estate Management
  getRealEstates() {
    return this.data.realEstates
  }

  purchaseRealEstate(type) {
    const realEstateType = this.realEstateTypes[type]
    if (!realEstateType) return false

    if (this.spendMoney(realEstateType.price)) {
      const realEstate = {
        id: this.generateId(),
        name: realEstateType.name,
        type: type,
        price: realEstateType.price,
        monthlyIncome: realEstateType.income,
        location: this.generateLocation(),
        purchaseDate: Date.now(),
      }

      this.data.realEstates.push(realEstate)
      this.addXP(200)
      this.showNotification(`Successfully purchased ${realEstate.name}!`, "success")
      return true
    }

    this.showNotification("Insufficient funds for real estate purchase!", "error")
    return false
  }

  // Prestige System
  getPrestigeItems() {
    return this.data.prestigeItems
  }

  purchasePrestigeItem(type) {
    const prestigeType = this.prestigeTypes[type]
    if (!prestigeType) return false

    if (this.spendMoney(prestigeType.price)) {
      const prestigeItem = {
        id: this.generateId(),
        name: prestigeType.name,
        type: type,
        price: prestigeType.price,
        prestigePoints: prestigeType.points,
        purchaseDate: Date.now(),
      }

      this.data.prestigeItems.push(prestigeItem)
      this.data.prestigePoints += prestigeType.points
      this.addXP(prestigeType.points)
      this.showNotification(`Purchased ${prestigeItem.name} for ${prestigeType.points} prestige points!`, "success")
      return true
    }

    this.showNotification("Insufficient funds for prestige item!", "error")
    return false
  }

  // Passive Income Calculation
  calculatePassiveIncome() {
    let income = 0

    // Business income
    this.data.businesses.forEach((business) => {
      let businessIncome = business.revenue * business.level

      // Employee bonuses
      business.employees.forEach((employeeId) => {
        const employee = this.data.employees.find((e) => e.id === employeeId)
        if (employee) {
          businessIncome += employee.bonus * employee.level
        }
      })

      income += businessIncome
    })

    // Real estate income
    this.data.realEstates.forEach((realEstate) => {
      income += realEstate.monthlyIncome
    })

    return income
  }

  // Net Worth Calculation
  calculateNetWorth() {
    let netWorth = this.data.totalMoney

    // Business values
    this.data.businesses.forEach((business) => {
      netWorth += business.cost * business.level * 0.8 // Depreciation
    })

    // Investment values
    this.data.investments.forEach((investment) => {
      netWorth += investment.shares * investment.currentPrice
    })

    // Real estate values
    this.data.realEstates.forEach((realEstate) => {
      netWorth += realEstate.price
    })

    // Prestige item values (depreciated)
    this.data.prestigeItems.forEach((item) => {
      netWorth += item.price * 0.5
    })

    return netWorth
  }

  // Passive Income System
  startPassiveIncome() {
    setInterval(() => {
      const hourlyIncome = this.calculatePassiveIncome()
      if (hourlyIncome > 0) {
        this.addMoney(hourlyIncome)
      }
    }, 60000) // Every minute (representing 1 hour in game time)
  }

  // Investment Price Updates
  startInvestmentUpdates() {
    setInterval(() => {
      this.updateInvestmentPrices()
    }, 5000) // Every 5 seconds
  }

  // Utility Functions
  formatMoney(amount) {
    if (amount >= 1e9) return (amount / 1e9).toFixed(1) + "B"
    if (amount >= 1e6) return (amount / 1e6).toFixed(1) + "M"
    if (amount >= 1e3) return (amount / 1e3).toFixed(1) + "K"
    return Math.floor(amount).toLocaleString()
  }

  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2)
  }

  generateEmployeeName() {
    const firstNames = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Avery", "Quinn", "Sage", "River"]
    const lastNames = [
      "Smith",
      "Johnson",
      "Williams",
      "Brown",
      "Jones",
      "Garcia",
      "Miller",
      "Davis",
      "Rodriguez",
      "Martinez",
    ]
    return (
      firstNames[Math.floor(Math.random() * firstNames.length)] +
      " " +
      lastNames[Math.floor(Math.random() * lastNames.length)]
    )
  }

  generateLocation() {
    const locations = [
      "New York",
      "Los Angeles",
      "Chicago",
      "Houston",
      "Phoenix",
      "Philadelphia",
      "San Antonio",
      "San Diego",
      "Dallas",
      "San Jose",
    ]
    return locations[Math.floor(Math.random() * locations.length)]
  }

  generateInvestmentName(type) {
    const names = {
      stock: ["TechCorp", "GlobalBank", "RetailGiant", "EnergyPlus", "HealthCare Inc", "AutoMotive Ltd"],
      crypto: ["Bitcoin", "Ethereum", "Cardano", "Solana", "Polygon", "Chainlink"],
      bonds: ["US Treasury", "Corporate Bond", "Municipal Bond", "High Yield Bond"],
      commodities: ["Gold", "Silver", "Oil", "Natural Gas", "Wheat", "Copper"],
    }
    const typeNames = names[type] || names.stock
    return typeNames[Math.floor(Math.random() * typeNames.length)]
  }

  generateInvestmentPrice(type) {
    const priceRanges = {
      stock: [10, 500],
      crypto: [0.01, 50000],
      bonds: [100, 1000],
      commodities: [20, 2000],
    }
    const range = priceRanges[type] || priceRanges.stock
    return Math.random() * (range[1] - range[0]) + range[0]
  }

  // Notification System
  showNotification(message, type = "info") {
    const event = new CustomEvent("showNotification", {
      detail: { message, type },
    })
    window.dispatchEvent(event)
  }

  // Data Persistence
  saveGame() {
    this.data.lastSave = Date.now()
    localStorage.setItem("idealBusinessEmpire", JSON.stringify(this.data))
  }

  loadGame() {
    const savedData = localStorage.getItem("idealBusinessEmpire")
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData)
        this.data = { ...this.data, ...parsed }

        // Calculate offline earnings
        const offlineTime = Date.now() - this.data.lastSave
        const offlineHours = Math.floor(offlineTime / (1000 * 60 * 60))
        if (offlineHours > 0) {
          const offlineEarnings = this.calculatePassiveIncome() * offlineHours
          if (offlineEarnings > 0) {
            this.addMoney(offlineEarnings)
            this.showNotification(
              `Welcome back! You earned $${this.formatMoney(offlineEarnings)} while away!`,
              "success",
            )
          }
        }
      } catch (error) {
        console.error("Error loading game data:", error)
      }
    }
  }

  // Leaderboard (Local)
  getLeaderboard() {
    // In a real SaaS, this would fetch from a server
    // For now, we'll create mock data based on the current player
    const playerData = {
      name: this.data.playerName,
      level: this.data.playerLevel,
      netWorth: this.calculateNetWorth(),
      prestigePoints: this.data.prestigePoints,
    }

    // Generate some mock competitors
    const mockPlayers = []
    for (let i = 0; i < 9; i++) {
      mockPlayers.push({
        name: this.generateEmployeeName(),
        level: Math.floor(Math.random() * 50) + 1,
        netWorth: Math.random() * 10000000,
        prestigePoints: Math.floor(Math.random() * 1000),
      })
    }

    const allPlayers = [playerData, ...mockPlayers]
    return allPlayers.sort((a, b) => b.netWorth - a.netWorth)
  }
}
