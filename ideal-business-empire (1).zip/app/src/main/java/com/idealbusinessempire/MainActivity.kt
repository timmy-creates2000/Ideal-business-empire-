package com.idealbusinessempire

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.idealbusinessempire.databinding.ActivityMainBinding
import com.idealbusinessempire.managers.GameManager
import com.idealbusinessempire.models.Business
import com.idealbusinessempire.adapters.BusinessAdapter

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var gameManager: GameManager
    private lateinit var businessAdapter: BusinessAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        gameManager = GameManager(this)
        setupUI()
        setupRecyclerView()
        updateUI()
    }

    private fun setupUI() {
        binding.apply {
            // Navigation buttons
            btnInvestments.setOnClickListener {
                startActivity(Intent(this@MainActivity, InvestmentActivity::class.java))
            }
            
            btnEmployees.setOnClickListener {
                startActivity(Intent(this@MainActivity, EmployeeActivity::class.java))
            }
            
            btnRealEstate.setOnClickListener {
                startActivity(Intent(this@MainActivity, RealEstateActivity::class.java))
            }
            
            btnPrestige.setOnClickListener {
                startActivity(Intent(this@MainActivity, PrestigeActivity::class.java))
            }
            
            btnLeaderboard.setOnClickListener {
                startActivity(Intent(this@MainActivity, LeaderboardActivity::class.java))
            }

            // Add new business button
            fabAddBusiness.setOnClickListener {
                startActivity(Intent(this@MainActivity, CreateBusinessActivity::class.java))
            }
        }
    }

    private fun setupRecyclerView() {
        businessAdapter = BusinessAdapter(gameManager.getBusinesses()) { business ->
            // Handle business click - open business details
            val intent = Intent(this, BusinessDetailActivity::class.java)
            intent.putExtra("business_id", business.id)
            startActivity(intent)
        }
        
        binding.recyclerViewBusinesses.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = businessAdapter
        }
    }

    private fun updateUI() {
        binding.apply {
            tvPlayerName.text = gameManager.getPlayerName()
            tvTotalMoney.text = "$$${gameManager.formatMoney(gameManager.getTotalMoney())}"
            tvNetWorth.text = "Net Worth: $$${gameManager.formatMoney(gameManager.getNetWorth())}"
            tvLevel.text = "Level ${gameManager.getPlayerLevel()}"
            
            // Update progress bar
            val (currentXP, requiredXP) = gameManager.getXPProgress()
            progressLevel.max = requiredXP
            progressLevel.progress = currentXP
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
        businessAdapter.notifyDataSetChanged()
    }
}
