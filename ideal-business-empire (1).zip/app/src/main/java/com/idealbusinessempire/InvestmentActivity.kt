package com.idealbusinessempire

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.idealbusinessempire.adapters.InvestmentAdapter
import com.idealbusinessempire.databinding.ActivityInvestmentBinding
import com.idealbusinessempire.managers.GameManager
import com.idealbusinessempire.models.Investment
import com.idealbusinessempire.models.InvestmentType
import kotlin.random.Random

class InvestmentActivity : AppCompatActivity() {
    private lateinit var binding: ActivityInvestmentBinding
    private lateinit var gameManager: GameManager
    private lateinit var investmentAdapter: InvestmentAdapter
    private val handler = Handler(Looper.getMainLooper())
    private val updateRunnable = object : Runnable {
        override fun run() {
            gameManager.updateInvestmentPrices()
            updateUI()
            handler.postDelayed(this, 5000) // Update every 5 seconds
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInvestmentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        gameManager = GameManager(this)
        setupUI()
        setupRecyclerView()
        startPriceUpdates()
    }

    private fun setupUI() {
        binding.apply {
            btnBack.setOnClickListener { finish() }
            
            btnBuyStock.setOnClickListener { buyInvestment(InvestmentType.STOCK) }
            btnBuyCrypto.setOnClickListener { buyInvestment(InvestmentType.CRYPTOCURRENCY) }
            btnBuyBonds.setOnClickListener { buyInvestment(InvestmentType.BONDS) }
            btnBuyCommodities.setOnClickListener { buyInvestment(InvestmentType.COMMODITIES) }
        }
        updateUI()
    }

    private fun setupRecyclerView() {
        investmentAdapter = InvestmentAdapter(gameManager.getInvestments()) { investment ->
            // Handle investment click - sell option
            sellInvestment(investment)
        }
        
        binding.recyclerViewInvestments.apply {
            layoutManager = LinearLayoutManager(this@InvestmentActivity)
            adapter = investmentAdapter
        }
    }

    private fun buyInvestment(type: InvestmentType) {
        val amount = 1000.0 // Default investment amount
        val price = generateRandomPrice(type)
        val shares = amount / price
        
        val investment = Investment(
            id = gameManager.generateId(),
            name = generateInvestmentName(type),
            type = type,
            amount = amount,
            shares = shares,
            purchasePrice = price,
            currentPrice = price
        )
        
        if (gameManager.makeInvestment(investment)) {
            investmentAdapter.notifyDataSetChanged()
            updateUI()
        }
    }

    private fun sellInvestment(investment: Investment) {
        val currentValue = investment.getCurrentValue()
        gameManager.addMoney(currentValue)
        // Remove from investments list (would need to implement in GameManager)
        updateUI()
    }

    private fun generateRandomPrice(type: InvestmentType): Double = when (type) {
        InvestmentType.STOCK -> Random.nextDouble(10.0, 500.0)
        InvestmentType.CRYPTOCURRENCY -> Random.nextDouble(0.01, 50000.0)
        InvestmentType.BONDS -> Random.nextDouble(100.0, 1000.0)
        InvestmentType.COMMODITIES -> Random.nextDouble(20.0, 2000.0)
    }

    private fun generateInvestmentName(type: InvestmentType): String = when (type) {
        InvestmentType.STOCK -> listOf("TechCorp", "GlobalBank", "RetailGiant", "EnergyPlus").random()
        InvestmentType.CRYPTOCURRENCY -> listOf("Bitcoin", "Ethereum", "Dogecoin", "Cardano").random()
        InvestmentType.BONDS -> listOf("Government Bond", "Corporate Bond", "Municipal Bond").random()
        InvestmentType.COMMODITIES -> listOf("Gold", "Silver", "Oil", "Wheat").random()
    }

    private fun updateUI() {
        binding.apply {
            tvTotalMoney.text = "$$${gameManager.formatMoney(gameManager.getTotalMoney())}"
            
            val investments = gameManager.getInvestments()
            var totalValue = 0.0
            var totalProfit = 0.0
            
            investments.forEach { investment ->
                totalValue += investment.getCurrentValue()
                totalProfit += investment.getProfitLoss()
            }
            
            tvPortfolioValue.text = "Portfolio: $$${gameManager.formatMoney(totalValue)}"
            tvTotalProfit.text = "P&L: $$${gameManager.formatMoney(totalProfit)}"
        }
        
        investmentAdapter.notifyDataSetChanged()
    }

    private fun startPriceUpdates() {
        handler.post(updateRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateRunnable)
    }
}
