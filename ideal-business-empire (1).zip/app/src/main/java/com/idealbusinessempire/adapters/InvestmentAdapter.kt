package com.idealbusinessempire.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.idealbusinessempire.databinding.ItemInvestmentBinding
import com.idealbusinessempire.models.Investment

class InvestmentAdapter(
    private val investments: List<Investment>,
    private val onInvestmentClick: (Investment) -> Unit
) : RecyclerView.Adapter<InvestmentAdapter.InvestmentViewHolder>() {

    class InvestmentViewHolder(private val binding: ItemInvestmentBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(investment: Investment, onInvestmentClick: (Investment) -> Unit) {
            binding.apply {
                tvInvestmentName.text = "${investment.getTypeIcon()} ${investment.name}"
                tvShares.text = "${String.format("%.4f", investment.shares)} shares"
                tvCurrentPrice.text = "$$${String.format("%.2f", investment.currentPrice)}"
                tvCurrentValue.text = "$$${String.format("%.2f", investment.getCurrentValue())}"
                
                val profitLoss = investment.getProfitLoss()
                val profitLossPercent = investment.getProfitLossPercentage()
                
                tvProfitLoss.text = "$$${String.format("%.2f", profitLoss)} (${String.format("%.1f", profitLossPercent)}%)"
                tvProfitLoss.setTextColor(if (profitLoss >= 0) Color.GREEN else Color.RED)
                
                root.setOnClickListener { onInvestmentClick(investment) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InvestmentViewHolder {
        val binding = ItemInvestmentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return InvestmentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: InvestmentViewHolder, position: Int) {
        holder.bind(investments[position], onInvestmentClick)
    }

    override fun getItemCount(): Int = investments.size
}
