package com.idealbusinessempire.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.idealbusinessempire.databinding.ItemBusinessBinding
import com.idealbusinessempire.models.Business

class BusinessAdapter(
    private val businesses: List<Business>,
    private val onBusinessClick: (Business) -> Unit
) : RecyclerView.Adapter<BusinessAdapter.BusinessViewHolder>() {

    class BusinessViewHolder(private val binding: ItemBusinessBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(business: Business, onBusinessClick: (Business) -> Unit) {
            binding.apply {
                tvBusinessName.text = business.name
                tvBusinessType.text = "${business.getTypeIcon()} ${business.type.name}"
                tvBusinessLevel.text = "Level ${business.level}"
                tvBusinessRevenue.text = "$$${String.format("%.2f", business.revenue)}/hour"
                
                if (business.isOwned) {
                    tvBusinessStatus.text = "OWNED"
                    tvBusinessStatus.setBackgroundColor(android.graphics.Color.GREEN)
                } else {
                    tvBusinessStatus.text = "$$${String.format("%.0f", business.cost)}"
                    tvBusinessStatus.setBackgroundColor(android.graphics.Color.BLUE)
                }
                
                root.setOnClickListener { onBusinessClick(business) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BusinessViewHolder {
        val binding = ItemBusinessBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BusinessViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BusinessViewHolder, position: Int) {
        holder.bind(businesses[position], onBusinessClick)
    }

    override fun getItemCount(): Int = businesses.size
}
