package com.idealbusinessempire.managers

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.idealbusinessempire.models.*
import java.text.DecimalFormat
import kotlin.random.Random

class GameManager(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("game_data", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    // Game state
    private var totalMoney: Double = 0.0
    private var playerName: String = "Business Tycoon"
    private var playerLevel: Int = 1
    private var playerXP: Int = 0
    private var businesses: MutableList<Business> = mutableListOf()
    private var employees: MutableList<Employee> = mutableListOf()
    private var investments: MutableList<Investment> = mutableListOf()
    private var realEstates: MutableList<RealEstate> = mutableListOf()
    private var prestigeItems: MutableList<PrestigeItem> = mutableListOf()

    init {
        loadGameData()
        if (businesses.isEmpty()) {
            initializeDefaultData()
        }
    }

    private fun initializeDefaultData() {
        totalMoney = 10000.0 // Starting money
        playerName = "Business Tycoon"
        playerLevel = 1
        playerXP = 0
        
        // Add some starter businesses
        businesses.add(Business(
            id = generateId(),
            name = "Corner Store",
            type = BusinessType.RETAIL,
            level = 1,
            revenue = 100.0,
            cost = 5000.0,
            isOwned = false
        ))
        
        saveGameData()
    }

    // Money management
    fun getTotalMoney(): Double = totalMoney
    
    fun addMoney(amount: Double) {
        totalMoney += amount
        addXP((amount / 100).toInt()) // Gain XP based on money earned
        saveGameData()
    }
    
    fun spendMoney(amount: Double): Boolean {
        return if (totalMoney >= amount) {
            totalMoney -= amount
            saveGameData()
            true
        } else false
    }

    // XP and Level system
    fun addXP(amount: Int) {
        playerXP += amount
        checkLevelUp()
        saveGameData()
    }
    
    private fun checkLevelUp() {
        val requiredXP = getRequiredXPForLevel(playerLevel + 1)
        if (playerXP >= requiredXP) {
            playerLevel++
            // Level up bonus
            addMoney(playerLevel * 1000.0)
            checkLevelUp() // Check for multiple level ups
        }
    }
    
    private fun getRequiredXPForLevel(level: Int): Int = level * 1000
    
    fun getXPProgress(): Pair<Int, Int> {
        val currentLevelXP = getRequiredXPForLevel(playerLevel)
        val nextLevelXP = getRequiredXPForLevel(playerLevel + 1)
        return Pair(playerXP - currentLevelXP, nextLevelXP - currentLevelXP)
    }

    // Business management
    fun getBusinesses(): List<Business> = businesses
    
    fun purchaseBusiness(business: Business): Boolean {
        return if (spendMoney(business.cost)) {
            business.isOwned = true
            business.purchaseDate = System.currentTimeMillis()
            addXP(100)
            true
        } else false
    }
    
    fun upgradeBusiness(businessId: String): Boolean {
        val business = businesses.find { it.id == businessId } ?: return false
        val upgradeCost = business.getUpgradeCost()
        
        return if (spendMoney(upgradeCost)) {
            business.level++
            business.revenue *= 1.5
            addXP(50)
            saveGameData()
            true
        } else false
    }

    // Employee management
    fun getEmployees(): List<Employee> = employees
    
    fun hireEmployee(employee: Employee): Boolean {
        return if (spendMoney(employee.salary * 12)) { // Pay yearly salary upfront
            employees.add(employee)
            addXP(25)
            saveGameData()
            true
        } else false
    }

    // Investment management
    fun getInvestments(): List<Investment> = investments
    
    fun makeInvestment(investment: Investment): Boolean {
        return if (spendMoney(investment.amount)) {
            investments.add(investment)
            addXP(20)
            saveGameData()
            true
        } else false
    }
    
    fun updateInvestmentPrices() {
        investments.forEach { investment ->
            val changePercent = Random.nextDouble(-0.1, 0.1) // -10% to +10% change
            investment.currentPrice *= (1 + changePercent)
            if (investment.currentPrice < 0.01) investment.currentPrice = 0.01
        }
        saveGameData()
    }

    // Real Estate management
    fun getRealEstates(): List<RealEstate> = realEstates
    
    fun purchaseRealEstate(realEstate: RealEstate): Boolean {
        return if (spendMoney(realEstate.price)) {
            realEstates.add(realEstate)
            addXP(200)
            saveGameData()
            true
        } else false
    }

    // Prestige system
    fun getPrestigeItems(): List<PrestigeItem> = prestigeItems
    
    fun purchasePrestigeItem(item: PrestigeItem): Boolean {
        return if (spendMoney(item.price)) {
            prestigeItems.add(item)
            addXP(item.prestigePoints)
            saveGameData()
            true
        } else false
    }

    // Calculate passive income
    fun calculatePassiveIncome(): Double {
        var income = 0.0
        
        // Business income
        businesses.filter { it.isOwned }.forEach { business ->
            income += business.revenue * business.level
        }
        
        // Real estate income
        realEstates.forEach { realEstate ->
            income += realEstate.monthlyIncome
        }
        
        // Employee productivity bonus
        employees.forEach { employee ->
            income += employee.productivityBonus
        }
        
        return income
    }

    // Net worth calculation
    fun getNetWorth(): Double {
        var netWorth = totalMoney
        
        // Add business values
        businesses.filter { it.isOwned }.forEach { business ->
            netWorth += business.cost * business.level * 0.8 // Depreciation
        }
        
        // Add investment values
        investments.forEach { investment ->
            netWorth += investment.currentPrice * investment.shares
        }
        
        // Add real estate values
        realEstates.forEach { realEstate ->
            netWorth += realEstate.price
        }
        
        // Add prestige item values
        prestigeItems.forEach { item ->
            netWorth += item.price * 0.5 // Luxury items depreciate
        }
        
        return netWorth
    }

    // Utility functions
    fun formatMoney(amount: Double): String {
        val formatter = DecimalFormat("#,###.##")
        return when {
            amount >= 1_000_000_000 -> "${formatter.format(amount / 1_000_000_000)}B"
            amount >= 1_000_000 -> "${formatter.format(amount / 1_000_000)}M"
            amount >= 1_000 -> "${formatter.format(amount / 1_000)}K"
            else -> formatter.format(amount)
        }
    }
    
    fun generateId(): String = System.currentTimeMillis().toString() + Random.nextInt(1000)
    
    fun getPlayerName(): String = playerName
    fun getPlayerLevel(): Int = playerLevel

    // Data persistence
    private fun saveGameData() {
        prefs.edit().apply {
            putString("total_money", totalMoney.toString())
            putString("player_name", playerName)
            putInt("player_level", playerLevel)
            putInt("player_xp", playerXP)
            putString("businesses", gson.toJson(businesses))
            putString("employees", gson.toJson(employees))
            putString("investments", gson.toJson(investments))
            putString("real_estates", gson.toJson(realEstates))
            putString("prestige_items", gson.toJson(prestigeItems))
            apply()
        }
    }
    
    private fun loadGameData() {
        totalMoney = prefs.getString("total_money", "10000.0")?.toDoubleOrNull() ?: 10000.0
        playerName = prefs.getString("player_name", "Business Tycoon") ?: "Business Tycoon"
        playerLevel = prefs.getInt("player_level", 1)
        playerXP = prefs.getInt("player_xp", 0)
        
        // Load lists
        val businessesJson = prefs.getString("businesses", "[]")
        businesses = gson.fromJson(businessesJson, object : TypeToken<MutableList<Business>>() {}.type) ?: mutableListOf()
        
        val employeesJson = prefs.getString("employees", "[]")
        employees = gson.fromJson(employeesJson, object : TypeToken<MutableList<Employee>>() {}.type) ?: mutableListOf()
        
        val investmentsJson = prefs.getString("investments", "[]")
        investments = gson.fromJson(investmentsJson, object : TypeToken<MutableList<Investment>>() {}.type) ?: mutableListOf()
        
        val realEstatesJson = prefs.getString("real_estates", "[]")
        realEstates = gson.fromJson(realEstatesJson, object : TypeToken<MutableList<RealEstate>>() {}.type) ?: mutableListOf()
        
        val prestigeItemsJson = prefs.getString("prestige_items", "[]")
        prestigeItems = gson.fromJson(prestigeItemsJson, object : TypeToken<MutableList<PrestigeItem>>() {}.type) ?: mutableListOf()
    }
}
