package com.idealbusinessempire.models

enum class EmployeeType {
    MANAGER, DEVELOPER, SALESPERSON, ACCOUNTANT, MARKETING, SECURITY, CHEF, PILOT
}

data class Employee(
    val id: String,
    var name: String,
    val type: EmployeeType,
    var level: Int = 1,
    var salary: Double,
    var productivityBonus: Double,
    var businessId: String = "", // Which business they work for
    var hireDate: Long = System.currentTimeMillis()
) {
    fun getUpgradeCost(): Double = salary * level * 2
    
    fun getTypeIcon(): String = when (type) {
        EmployeeType.MANAGER -> "👔"
        EmployeeType.DEVELOPER -> "👨‍💻"
        EmployeeType.SALESPERSON -> "🤝"
        EmployeeType.ACCOUNTANT -> "📊"
        EmployeeType.MARKETING -> "📢"
        EmployeeType.SECURITY -> "🛡️"
        EmployeeType.CHEF -> "👨‍🍳"
        EmployeeType.PILOT -> "👨‍✈️"
    }
    
    fun getSkillDescription(): String = when (type) {
        EmployeeType.MANAGER -> "Increases overall business efficiency"
        EmployeeType.DEVELOPER -> "Boosts IT and tech business revenue"
        EmployeeType.SALESPERSON -> "Increases retail and sales revenue"
        EmployeeType.ACCOUNTANT -> "Reduces business costs and taxes"
        EmployeeType.MARKETING -> "Attracts more customers"
        EmployeeType.SECURITY -> "Protects business assets"
        EmployeeType.CHEF -> "Improves restaurant quality"
        EmployeeType.PILOT -> "Essential for airline operations"
    }
}
