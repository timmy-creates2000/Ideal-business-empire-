package com.idealbusinessempire.models

enum class RealEstateType {
    APARTMENT, HOUSE, MANSION, OFFICE_BUILDING, SHOPPING_MALL, WAREHOUSE, PENTHOUSE
}

data class RealEstate(
    val id: String,
    var name: String,
    val type: RealEstateType,
    var price: Double,
    var monthlyIncome: Double,
    var location: String,
    var purchaseDate: Long = 0L
) {
    fun getTypeIcon(): String = when (type) {
        RealEstateType.APARTMENT -> "🏠"
        RealEstateType.HOUSE -> "🏡"
        RealEstateType.MANSION -> "🏰"
        RealEstateType.OFFICE_BUILDING -> "🏢"
        RealEstateType.SHOPPING_MALL -> "🏬"
        RealEstateType.WAREHOUSE -> "🏭"
        RealEstateType.PENTHOUSE -> "🌆"
    }
    
    fun getROI(): Double = (monthlyIncome * 12 / price) * 100
}
