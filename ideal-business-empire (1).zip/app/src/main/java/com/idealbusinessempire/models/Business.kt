package com.idealbusinessempire.models

enum class BusinessType {
    RETAIL, RESTAURANT, BANK, AIRLINE, CLOTHING, IT, BLOCKCHAIN, HOTEL
}

data class Business(
    val id: String,
    var name: String,
    val type: BusinessType,
    var level: Int = 1,
    var revenue: Double,
    val cost: Double,
    var isOwned: Boolean = false,
    var purchaseDate: Long = 0L,
    var employees: MutableList<String> = mutableListOf() // Employee IDs
) {
    fun getUpgradeCost(): Double = cost * level * 0.5
    
    fun getTypeIcon(): String = when (type) {
        BusinessType.RETAIL -> "🏪"
        BusinessType.RESTAURANT -> "🍽️"
        BusinessType.BANK -> "🏦"
        BusinessType.AIRLINE -> "✈️"
        BusinessType.CLOTHING -> "👕"
        BusinessType.IT -> "💻"
        BusinessType.BLOCKCHAIN -> "₿"
        BusinessType.HOTEL -> "🏨"
    }
    
    fun getDescription(): String = when (type) {
        BusinessType.RETAIL -> "Sell products to customers"
        BusinessType.RESTAURANT -> "Serve delicious meals"
        BusinessType.BANK -> "Provide financial services"
        BusinessType.AIRLINE -> "Transport passengers worldwide"
        BusinessType.CLOTHING -> "Fashion and apparel business"
        BusinessType.IT -> "Technology solutions and software"
        BusinessType.BLOCKCHAIN -> "Cryptocurrency and blockchain services"
        BusinessType.HOTEL -> "Hospitality and accommodation"
    }
}
