package com.idealbusinessempire.models

enum class InvestmentType {
    STOCK, CRYPTOCURRENCY, BONDS, COMMODITIES
}

data class Investment(
    val id: String,
    var name: String,
    val type: InvestmentType,
    var amount: Double, // Amount invested
    var shares: Double, // Number of shares/coins owned
    var purchasePrice: Double, // Price when purchased
    var currentPrice: Double, // Current market price
    var purchaseDate: Long = System.currentTimeMillis()
) {
    fun getCurrentValue(): Double = shares * currentPrice
    fun getProfitLoss(): Double = getCurrentValue() - amount
    fun getProfitLossPercentage(): Double = ((currentPrice - purchasePrice) / purchasePrice) * 100
    
    fun getTypeIcon(): String = when (type) {
        InvestmentType.STOCK -> "📈"
        InvestmentType.CRYPTOCURRENCY -> "₿"
        InvestmentType.BONDS -> "📋"
        InvestmentType.COMMODITIES -> "🥇"
    }
}
