package com.idealbusinessempire.models

enum class PrestigeType {
    LUXURY_CAR, YACHT, PRIVATE_JET, WATCH, JEWELRY, ART, WINE_COLLECTION
}

data class PrestigeItem(
    val id: String,
    var name: String,
    val type: PrestigeType,
    var price: Double,
    var prestigePoints: Int,
    var description: String,
    var purchaseDate: Long = 0L
) {
    fun getTypeIcon(): String = when (type) {
        PrestigeType.LUXURY_CAR -> "🏎️"
        PrestigeType.YACHT -> "🛥️"
        PrestigeType.PRIVATE_JET -> "🛩️"
        PrestigeType.WATCH -> "⌚"
        PrestigeType.JEWELRY -> "💎"
        PrestigeType.ART -> "🖼️"
        PrestigeType.WINE_COLLECTION -> "🍷"
    }
}
